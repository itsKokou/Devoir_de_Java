package ism.services;

import ism.entities.Unite;

public interface UniteService extends IService<Unite>{
    
}
