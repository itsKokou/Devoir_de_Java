package ism.repositories.list;


import ism.entities.Unite;

public class TableUnites extends Table<Unite> {

}
