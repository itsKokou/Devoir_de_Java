package ism.repositories.list;


import ism.entities.ArticleConfection;

public class TableArticleConfections extends Table<ArticleConfection> {
    
}
