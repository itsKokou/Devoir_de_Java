package ism.repositories.bd;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MySql {
    protected Connection conn=null;

    public void connexion(){
        if(conn==null){
            try {
                Class.forName("com.mysql.cj.jdbc.Driver");
                conn = DriverManager.getConnection(
                    "jdbc:mysql://localhost:3306/gestion_atelier_bd", "root", ""
                ); 
            } catch (Exception e) {
                System.out.println("Erreur de connexion à la bd");
            }
        }
    }

    public void closeConnexion(){
        try {
            conn.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public ResultSet executeSelect(String sql, int id){
        ResultSet rs = null;
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            if (id!=0) {
                statement.setInt(1, id);
            }
            rs = statement.executeQuery();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return rs;           
    }

    public int executeUpdate(String sql){
        int nbreLigne=0;
        try {
            PreparedStatement statement = conn.prepareStatement(sql);
            //Mapping des types
            // statement.setString(1, data.getLibelle());
            // statement.setInt(2, data.getId());
            nbreLigne = statement.executeUpdate();
            statement.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return nbreLigne;         
    }
}
