package ism.services;

import ism.entities.Categorie;

public interface CategorieService extends IService<Categorie>{
    
}
