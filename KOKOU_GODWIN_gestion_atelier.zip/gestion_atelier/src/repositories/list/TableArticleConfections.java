package repositories.list;


import entities.ArticleConfection;

public class TableArticleConfections extends Table<ArticleConfection> {
    
}
