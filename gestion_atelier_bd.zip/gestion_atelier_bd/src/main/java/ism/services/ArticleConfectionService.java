package ism.services;

import ism.entities.ArticleConfection;

public interface ArticleConfectionService extends IService<ArticleConfection>{
    
}
