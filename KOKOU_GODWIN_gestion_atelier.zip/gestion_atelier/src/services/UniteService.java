package services;

import entities.Unite;

public interface UniteService extends IService<Unite>{
    
}
